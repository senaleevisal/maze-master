export interface PageProps {
  params: {
    slug: string;
  };
  searchParams: {};
}
